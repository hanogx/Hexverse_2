import { createEngine, startLoop } from "../../core/engine.js";
import { SceneBase } from "../../core/sceneBase.js";
import { createSpaceBackground } from "../../core/env/spaceBackground.js";
import { RunBackgroundPreset } from "../../core/env/presets.js";
import { openPentaRunSelection } from "./selectUI.js";
import { PentaGame } from "./runtime/PentaGame.js";

class PentaScene extends SceneBase{
  constructor(engine, canvas){
    super(engine, canvas);
    this.scene = new BABYLON.Scene(engine);
    this.setupBasics({ cameraTarget: new BABYLON.Vector3(0, 1, 0), radius: 20, glow: true });
    createSpaceBackground(this.scene, RunBackgroundPreset);
  }
}

window.addEventListener("DOMContentLoaded", () => {
  const canvas = document.getElementById("renderCanvas");
  const engine = createEngine(canvas);
  const penta = new PentaScene(engine, canvas);

  // Bir frame sonra aç (overlay görünürlüğü için)
  requestAnimationFrame(() => {
openPentaRunSelection({
  onConfirm: (stageId) => {
    // Penta oyunu başlat
    const game = new PentaGame(penta.scene, stageId, {
      onExit: () => { location.href = "./index.html"; } // veya seçim ekranına geri dönmek istersen burada openPentaRunSelection çağırabilirsin
    });

    // Render loop’u başlat (eğer henüz başlamadıysa)
    startLoop(engine, penta.scene);
  },
  onCancel: () => { location.href = "./index.html"; }
});

  });

  // Emniyet: 400ms içinde overlay yoksa tekrar dene
  setTimeout(() => {
    if (!document.getElementById("hexrun-select")) {
      requestAnimationFrame(() => {
        openPentaRunSelection({
          onConfirm: (stageId) => {
            hud.onBack(() => location.href = "./index.html");
            startLoop(engine, penta.scene);
          },
          onCancel: () => { location.href = "./index.html"; }
        });
      });
    }
  }, 400);
});
