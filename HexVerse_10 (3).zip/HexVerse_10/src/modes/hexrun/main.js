// src/modes/hexrun/main.js
import { Store } from "../../core/store.js";
import { Game } from "./systems/game.js";

window.addEventListener("DOMContentLoaded", () => {
  if (Store.get("energy") == null)     Store.set("energy", 120);
if (Store.get("pentaRelic") == null) Store.set("pentaRelic", 3);
  const selected = Store.get("selectedHexType", "em"); // default em
  const canvas   = document.getElementById("renderCanvas");

  // HUD’a yaz
  const hudType = document.getElementById("hudType");
  hudType.textContent = `HEX: ${selected.toUpperCase()}`;

  // Oyunu başlat
  const game = new Game({ canvas, initialFace: selected });

  // Basit HUD güncelle
  const hudTime  = document.getElementById("hudTime");
  const hudSpawn = document.getElementById("hudSpawn");
  const hudHits  = document.getElementById("hudHits");

  game.onTick(({ seconds, spawned, hits }) => {
    const m = Math.floor(seconds / 60).toString().padStart(2,"0");
    const s = Math.floor(seconds % 60).toString().padStart(2,"0");
    hudTime.textContent  = `${m}:${s}`;
    hudSpawn.textContent = spawned;
    hudHits.textContent  = hits;
  });

  // ESC = Hub’a dönüş
  window.addEventListener("keydown", (e)=>{
    if (e.key === "Escape") window.location.href = "../../goldberg.html";
  });
});
