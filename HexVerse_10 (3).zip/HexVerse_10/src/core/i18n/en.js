export const en = {
  hub_enter_hexrun: 'Enter HexRun',
  hub_enter_pentarun: 'Enter PentaRun',
  back_to_hub: 'Back to Hub',
  hexrun_title: 'HexRun',
  pentarun_title: 'PentaRun',
  energy: 'Energy',
  paused: 'Paused',
  select_stage: 'Select a Stage',
  enter: 'Enter',
  requirements: 'Requirements',
  not_enough_resources: 'Not enough resources',
};
